import { NextRequest, NextResponse } from 'next/server';

const AVATAR_URL = process.env.AVATAR_SERVICE_URL || 'http://localhost:8000';
const AVATAR_ENABLED = process.env.AVATAR_SERVICE_ENABLED === 'true';

function buildUpstreamUrl(segments: string[]): string {
  const path = segments.join('/');
  // Media requests: /api/avatar/media/... → AVATAR_URL/media/...
  if (path.startsWith('media/')) {
    return `${AVATAR_URL.replace(/\/$/, '')}/${path}`;
  }
  // API requests: /api/avatar/... → AVATAR_URL/api/avatar/...
  return `${AVATAR_URL.replace(/\/$/, '')}/api/avatar/${path}`;
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> },
) {
  if (!AVATAR_ENABLED) {
    return NextResponse.json({ error: 'Avatar service is not enabled' }, { status: 503 });
  }

  const { path } = await params;
  const url = buildUpstreamUrl(path);

  try {
    const body = await request.json();
    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    if (!resp.ok) {
      const errorText = await resp.text().catch(() => 'Unknown error');
      return NextResponse.json({ error: errorText }, { status: resp.status });
    }

    const data = await resp.json();
    return NextResponse.json(data);
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Avatar service unreachable';
    return NextResponse.json({ error: message }, { status: 502 });
  }
}

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> },
) {
  if (!AVATAR_ENABLED) {
    return NextResponse.json({ error: 'Avatar service is not enabled' }, { status: 503 });
  }

  const { path } = await params;
  const url = buildUpstreamUrl(path);

  try {
    const resp = await fetch(url);

    if (!resp.ok) {
      const errorText = await resp.text().catch(() => 'Unknown error');
      return NextResponse.json({ error: errorText }, { status: resp.status });
    }

    // Binary content (audio files)
    const contentType = resp.headers.get('content-type') || '';
    if (
      contentType.includes('audio/') ||
      contentType.includes('application/octet-stream') ||
      path.join('/').startsWith('media/')
    ) {
      const buffer = await resp.arrayBuffer();
      return new NextResponse(buffer, {
        status: 200,
        headers: {
          'Content-Type': contentType || 'audio/mpeg',
          'Cache-Control': 'public, max-age=3600',
        },
      });
    }

    const data = await resp.json();
    return NextResponse.json(data);
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Avatar service unreachable';
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
