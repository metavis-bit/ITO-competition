import { create } from 'zustand';
import type { AvatarVisualState, SpeechTask } from '@/components/avatar/types';

interface AvatarStore {
  // State
  enabled: boolean;
  sessionId: string | null;
  currentTask: SpeechTask | null;
  avatarVisualState: AvatarVisualState;
  subtitle: string | null;
  audioUrl: string | null;
  isSpeaking: boolean;
  hasError: boolean;
  serviceAvailable: boolean;

  // Actions
  setEnabled: (enabled: boolean) => void;
  loadSession: (
    sessionId: string,
    payload: {
      project_intro?: { title: string; description: string };
      ppt_scripts?: Array<{ slide_no: number; script: string }>;
    },
  ) => Promise<void>;
  triggerProjectIntro: (sessionId: string) => Promise<void>;
  triggerPPTExplain: (sessionId: string, slideNo: number) => Promise<void>;
  triggerBroadcast: (sessionId: string, message: string) => Promise<void>;
  setCurrentTask: (task: SpeechTask) => void;
  reset: () => void;
  checkHealth: () => Promise<boolean>;
}

function deriveVisualState(task: SpeechTask | null): AvatarVisualState {
  if (!task) return 'idle';
  if (task.status === 'failed' || task.avatar_state === 'error') return 'error';
  if (task.avatar_state === 'paused') return 'paused';
  if (task.avatar_state === 'speaking') {
    if (task.mode === 'project_intro') return 'greet';
    if (task.mode === 'result_broadcast') return 'notify';
    return 'explain';
  }
  return 'idle';
}

function rewriteAudioUrl(url: string | null): string | null {
  if (!url) return null;
  // Rewrite backend media paths to go through our proxy
  // /media/cache/xxx.mp3 → /api/avatar/media/cache/xxx.mp3
  if (url.startsWith('/media/')) {
    return `/api/avatar${url}`;
  }
  return url;
}

async function avatarFetch<T>(path: string, body?: object): Promise<T> {
  const opts: RequestInit = {
    method: body ? 'POST' : 'GET',
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  };
  const resp = await fetch(`/api/avatar/${path}`, opts);
  if (!resp.ok) {
    throw new Error(`Avatar API error ${resp.status}`);
  }
  return resp.json() as Promise<T>;
}

export const useAvatarStore = create<AvatarStore>((set, get) => ({
  enabled: true,
  sessionId: null,
  currentTask: null,
  avatarVisualState: 'idle',
  subtitle: null,
  audioUrl: null,
  isSpeaking: false,
  hasError: false,
  serviceAvailable: false,

  setEnabled: (enabled) => set({ enabled }),

  checkHealth: async () => {
    try {
      await fetch('/api/avatar/health', { signal: AbortSignal.timeout(3000) });
      set({ serviceAvailable: true });
      return true;
    } catch {
      set({ serviceAvailable: false, enabled: false });
      return false;
    }
  },

  loadSession: async (sessionId, payload) => {
    try {
      await avatarFetch('session/load', {
        session_id: sessionId,
        ...payload,
      });
      set({ sessionId, hasError: false });
    } catch {
      set({ hasError: true, enabled: false });
    }
  },

  triggerProjectIntro: async (sessionId) => {
    try {
      const task = await avatarFetch<SpeechTask>('project-intro', { session_id: sessionId });
      get().setCurrentTask(task);
    } catch {
      set({ hasError: true });
    }
  },

  triggerPPTExplain: async (sessionId, slideNo) => {
    try {
      const task = await avatarFetch<SpeechTask>('ppt-explain', {
        session_id: sessionId,
        slide_no: slideNo,
      });
      get().setCurrentTask(task);
    } catch {
      set({ hasError: true });
    }
  },

  triggerBroadcast: async (sessionId, message) => {
    try {
      const task = await avatarFetch<SpeechTask>('broadcast', {
        session_id: sessionId,
        message,
      });
      get().setCurrentTask(task);
    } catch {
      set({ hasError: true });
    }
  },

  setCurrentTask: (task) => {
    const visualState = deriveVisualState(task);
    set({
      currentTask: task,
      avatarVisualState: visualState,
      subtitle: task.subtitle || null,
      audioUrl: rewriteAudioUrl(task.audio_url),
      isSpeaking: task.avatar_state === 'speaking',
      hasError: task.status === 'failed',
    });
  },

  reset: () =>
    set({
      sessionId: null,
      currentTask: null,
      avatarVisualState: 'idle',
      subtitle: null,
      audioUrl: null,
      isSpeaking: false,
      hasError: false,
    }),
}));
