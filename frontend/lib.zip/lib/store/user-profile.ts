﻿/**
 * User Profile Store
 * Persists avatar, nickname & bio to localStorage
 */

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

/** Predefined avatar options */
export const AVATAR_OPTIONS = [
  '/avatars/user.png',
  '/avatars/teacher-2.png',
  '/avatars/assist-2.png',
  '/avatars/clown-2.png',
  '/avatars/curious-2.png',
  '/avatars/note-taker-2.png',
  '/avatars/thinker-2.png',
] as const;

export interface UserProfileState {
  /** Local avatar path or data-URL (for custom uploads) */
  avatar: string;
  nickname: string;
  bio: string;
  /** Subject taught, e.g. "高中生物" */
  subject: string;
  /** Grade level, e.g. "高一" */
  gradeLevel: string;
  /** Teaching style preference, e.g. "互动探究" */
  teachingStyle: string;
  setAvatar: (avatar: string) => void;
  setNickname: (nickname: string) => void;
  setBio: (bio: string) => void;
  setSubject: (subject: string) => void;
  setGradeLevel: (gradeLevel: string) => void;
  setTeachingStyle: (teachingStyle: string) => void;
}

export const useUserProfileStore = create<UserProfileState>()(
  persist(
    (set) => ({
      avatar: AVATAR_OPTIONS[0],
      nickname: '',
      bio: '',
      subject: '生物',
      gradeLevel: '',
      teachingStyle: '',
      setAvatar: (avatar) => set({ avatar }),
      setNickname: (nickname) => set({ nickname }),
      setBio: (bio) => set({ bio }),
      setSubject: (subject) => set({ subject }),
      setGradeLevel: (gradeLevel) => set({ gradeLevel }),
      setTeachingStyle: (teachingStyle) => set({ teachingStyle }),
    }),
    {
      name: 'user-profile-storage',
    },
  ),
);

