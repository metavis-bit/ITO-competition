'use client';

import { useState, useCallback, useRef } from 'react';
import { nanoid } from 'nanoid';
import type { BackendTeachingIntent } from '@/lib/types/backend';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

export interface DialogueMetadata {
  state: string;
  isComplete: boolean;
  missingFields: string[];
  collectedInfo: string;
}

interface UseHomepageChatReturn {
  messages: ChatMessage[];
  sessionId: string;
  isStreaming: boolean;
  intentCollected: boolean;
  collectedIntent: BackendTeachingIntent | null;
  dialogueMeta: DialogueMetadata | null;
  sendMessage: (text: string) => Promise<void>;
  resetDialogue: () => void;
}

/**
 * Lightweight hook for multi-turn dialogue on the homepage.
 * Communicates with the backend dialogue manager via /api/chat SSE proxy.
 */
export function useHomepageChat(): UseHomepageChatReturn {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [intentCollected, setIntentCollected] = useState(false);
  const [collectedIntent, setCollectedIntent] = useState<BackendTeachingIntent | null>(null);
  const [dialogueMeta, setDialogueMeta] = useState<DialogueMetadata | null>(null);
  const sessionIdRef = useRef<string>(`dialogue_${nanoid()}`);
  const abortRef = useRef<AbortController | null>(null);

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim() || isStreaming) return;

    // Append user message
    const userMsg: ChatMessage = { id: nanoid(), role: 'user', content: text.trim() };
    setMessages((prev) => [...prev, userMsg]);
    setIsStreaming(true);

    // Prepare assistant message placeholder
    const assistantId = nanoid();
    setMessages((prev) => [...prev, { id: assistantId, role: 'assistant', content: '' }]);

    const controller = new AbortController();
    abortRef.current = controller;

    try {
      // Build request in the format /api/chat expects for backend proxy mode
      const body = {
        messages: [
          {
            id: nanoid(),
            role: 'user' as const,
            parts: [{ type: 'text' as const, text: text.trim() }],
          },
        ],
        storeState: {
          stage: { id: sessionIdRef.current },
          scenes: [],
          currentSceneId: null,
          mode: 'autonomous',
        },
        config: { agentIds: ['ito-teaching-assistant'] },
      };

      const resp = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: controller.signal,
      });

      if (!resp.ok || !resp.body) {
        throw new Error(`Chat failed: ${resp.status}`);
      }

      // Parse SSE stream
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          const dataStr = line.slice(6).trim();
          if (!dataStr) continue;

          try {
            const event = JSON.parse(dataStr);

            if (event.type === 'text_delta' && event.data?.content) {
              // Append text to the assistant message
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === assistantId
                    ? { ...m, content: m.content + event.data.content }
                    : m,
                ),
              );
            }

            if (event.type === 'action') {
              if (event.data?.actionName === 'intent_collected') {
                setIntentCollected(true);
                setCollectedIntent(event.data.params as BackendTeachingIntent);
              }
              if (event.data?.actionName === 'dialogue_state') {
                setDialogueMeta({
                  state: event.data.params?.state || 'collecting',
                  isComplete: !!event.data.params?.is_complete,
                  missingFields: (event.data.params?.missing_fields as string[]) || [],
                  collectedInfo: (event.data.params?.collected_info as string) || '',
                });
                // Also check if dialogue is in ready/confirming state
                if (event.data.params?.is_complete) {
                  setIntentCollected(true);
                }
              }
            }
          } catch {
            // Skip non-JSON lines
          }
        }
      }
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') return;
      // On error, update assistant message with error text
      setMessages((prev) =>
        prev.map((m) =>
          m.id === assistantId && !m.content
            ? { ...m, content: '抱歉，对话服务暂时不可用，请稍后重试。' }
            : m,
        ),
      );
    } finally {
      setIsStreaming(false);
      abortRef.current = null;
    }
  }, [isStreaming]);

  const resetDialogue = useCallback(() => {
    if (abortRef.current) abortRef.current.abort();
    setMessages([]);
    setIsStreaming(false);
    setIntentCollected(false);
    setCollectedIntent(null);
    setDialogueMeta(null);
    sessionIdRef.current = `dialogue_${nanoid()}`;
  }, []);

  return {
    messages,
    sessionId: sessionIdRef.current,
    isStreaming,
    intentCollected,
    collectedIntent,
    dialogueMeta,
    sendMessage,
    resetDialogue,
  };
}
