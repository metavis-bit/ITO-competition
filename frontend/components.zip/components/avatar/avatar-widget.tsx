'use client';

import { useState, useEffect, useRef } from 'react';
import { Minimize2, Maximize2, Volume2, VolumeX, Send, MessageCircle, RefreshCw } from 'lucide-react';
import { AvatarRenderer } from './avatar-renderer';
import { useAvatarStore } from '@/lib/store/avatar';
import './avatar.css';

interface AvatarWidgetProps {
  currentSlideNo?: number;
  size?: number;
}

/**
 * Digital Human Avatar Widget.
 * Always renders (idle SVG if service is offline), connects to avatar_service when available.
 * Click avatar to interact: greet, ask questions, or trigger explanations.
 */
export function AvatarWidget({ currentSlideNo, size = 200 }: AvatarWidgetProps) {
  const {
    serviceAvailable,
    avatarVisualState,
    subtitle,
    audioUrl,
    isSpeaking,
    hasError,
    checkHealth,
    triggerPPTExplain,
    triggerBroadcast,
    triggerProjectIntro,
    sessionId,
  } = useAvatarStore();

  const [collapsed, setCollapsed] = useState(false);
  const [muted, setMuted] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [sending, setSending] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Check avatar service health on mount
  useEffect(() => {
    checkHealth();
  }, [checkHealth]);

  // Trigger slide explanation when slide changes (only if service is live)
  useEffect(() => {
    if (serviceAvailable && sessionId && currentSlideNo && currentSlideNo > 0) {
      triggerPPTExplain(sessionId, currentSlideNo);
    }
  }, [serviceAvailable, sessionId, currentSlideNo, triggerPPTExplain]);

  // Focus input when chat opens
  useEffect(() => {
    if (chatOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [chatOpen]);

  const handleAvatarClick = () => {
    if (serviceAvailable && sessionId) {
      // If service is live, toggle chat panel
      setChatOpen(!chatOpen);
    } else if (!serviceAvailable) {
      // Try reconnecting
      checkHealth();
    }
  };

  const handleSend = async () => {
    if (!chatInput.trim() || !sessionId || sending) return;
    setSending(true);
    try {
      await triggerBroadcast(sessionId, chatInput.trim());
      setChatInput('');
    } finally {
      setSending(false);
    }
  };

  const handleGreet = async () => {
    if (!sessionId) return;
    await triggerProjectIntro(sessionId);
  };

  const handleExplainSlide = async () => {
    if (!sessionId || !currentSlideNo) return;
    await triggerPPTExplain(sessionId, currentSlideNo);
  };

  if (collapsed) {
    return (
      <button
        onClick={() => setCollapsed(false)}
        className="w-12 h-12 rounded-full bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm shadow-lg border border-gray-200/60 dark:border-gray-700/60 flex items-center justify-center hover:scale-105 active:scale-95 transition-transform"
        title="展开数字人助教"
      >
        <Maximize2 className="w-4 h-4 text-gray-600 dark:text-gray-300" />
      </button>
    );
  }

  // Determine display state: use live state if service is up, otherwise idle
  const displayState = serviceAvailable ? avatarVisualState : 'idle';
  const displaySubtitle = serviceAvailable
    ? subtitle
    : '点击我开始互动 👋';

  return (
    <div className="flex flex-col items-center gap-2">
      {/* Controls */}
      <div className="flex items-center gap-1">
        {serviceAvailable && (
          <>
            <button
              onClick={() => setChatOpen(!chatOpen)}
              className="w-7 h-7 rounded-full bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm shadow-sm border border-gray-200/40 dark:border-gray-700/40 flex items-center justify-center hover:bg-emerald-50 dark:hover:bg-emerald-900/20 hover:text-emerald-600 transition-colors"
              title="与数字人对话"
            >
              <MessageCircle className="w-3.5 h-3.5 text-gray-500" />
            </button>
            <button
              onClick={() => setMuted(!muted)}
              className="w-7 h-7 rounded-full bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm shadow-sm border border-gray-200/40 dark:border-gray-700/40 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              title={muted ? '取消静音' : '静音'}
            >
              {muted ? (
                <VolumeX className="w-3.5 h-3.5 text-gray-500" />
              ) : (
                <Volume2 className="w-3.5 h-3.5 text-gray-500" />
              )}
            </button>
          </>
        )}
        <button
          onClick={() => setCollapsed(true)}
          className="w-7 h-7 rounded-full bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm shadow-sm border border-gray-200/40 dark:border-gray-700/40 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          title="收起"
        >
          <Minimize2 className="w-3.5 h-3.5 text-gray-500" />
        </button>
      </div>

      {/* Avatar — clickable */}
      <button
        onClick={handleAvatarClick}
        className="cursor-pointer hover:scale-[1.03] active:scale-[0.97] transition-transform focus:outline-none rounded-full"
        title={serviceAvailable ? '点击与数字人助教互动' : '点击重新连接'}
      >
        <AvatarRenderer
          avatarState={displayState}
          subtitle={displaySubtitle}
          audioUrl={serviceAvailable && !muted ? audioUrl : null}
          autoPlay={serviceAvailable && !muted}
          size={size}
          showSubtitle={true}
          isSpeaking={serviceAvailable ? isSpeaking : false}
          hasError={serviceAvailable ? hasError : false}
        />
      </button>

      {/* Quick actions & chat panel */}
      {serviceAvailable && chatOpen && (
        <div className="w-56 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-xl shadow-lg border border-gray-200/60 dark:border-gray-700/60 overflow-hidden animate-in fade-in slide-in-from-bottom-2 duration-200">
          {/* Quick action buttons */}
          <div className="p-2 flex gap-1.5 border-b border-gray-100 dark:border-gray-800">
            <button
              onClick={handleGreet}
              className="flex-1 px-2 py-1.5 text-[11px] rounded-lg bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-900/30 transition-colors font-medium"
            >
              👋 打招呼
            </button>
            {currentSlideNo && (
              <button
                onClick={handleExplainSlide}
                className="flex-1 px-2 py-1.5 text-[11px] rounded-lg bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors font-medium"
              >
                📖 讲解本页
              </button>
            )}
          </div>
          {/* Chat input */}
          <div className="p-2 flex gap-1.5">
            <input
              ref={inputRef}
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="输入问题..."
              className="flex-1 px-2.5 py-1.5 text-xs border rounded-lg bg-background focus:outline-none focus:ring-1 focus:ring-emerald-500/40"
              disabled={sending}
            />
            <button
              onClick={handleSend}
              disabled={sending || !chatInput.trim()}
              className="w-7 h-7 rounded-lg bg-emerald-500 text-white flex items-center justify-center hover:bg-emerald-600 disabled:opacity-40 disabled:cursor-not-allowed transition-colors shrink-0"
            >
              <Send className="w-3 h-3" />
            </button>
          </div>
        </div>
      )}

      {/* Service status indicator */}
      {!serviceAvailable && (
        <div className="flex flex-col items-center gap-1">
          <button
            onClick={() => checkHealth()}
            className="flex items-center gap-1 text-[10px] text-amber-600 dark:text-amber-400 hover:text-emerald-500 transition-colors"
          >
            <RefreshCw className="w-3 h-3" />
            数字人服务未连接
          </button>
          <span className="text-[9px] text-muted-foreground/40 text-center leading-tight max-w-[160px]">
            请启动数字人服务 (端口 8000)
          </span>
        </div>
      )}
    </div>
  );
}
