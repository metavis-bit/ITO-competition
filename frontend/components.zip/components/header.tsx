'use client';

import {
  Settings,
  Sun,
  Moon,
  Monitor,
  ArrowLeft,
  Loader2,
  Download,
  FileDown,
  Package,
  Film,
  Archive,
  History,
  MessageSquarePlus,
} from 'lucide-react';
import { useI18n } from '@/lib/hooks/use-i18n';
import { useTheme } from '@/lib/hooks/use-theme';
import { useState, useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { SettingsDialog } from './settings';
import { cn } from '@/lib/utils';
import { useSettingsStore } from '@/lib/store/settings';
import { useStageStore } from '@/lib/store/stage';
import { useMediaGenerationStore } from '@/lib/store/media-generation';
import { useExportPPTX } from '@/lib/export/use-export-pptx';
import { toast } from 'sonner';

interface HeaderProps {
  readonly currentSceneTitle: string;
}

export function Header({ currentSceneTitle }: HeaderProps) {
  const { t, locale, setLocale } = useI18n();
  const { theme, setTheme } = useTheme();
  const router = useRouter();
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settingsSection, _setSettingsSection] = useState<
    import('@/lib/types/settings').SettingsSection | undefined
  >(undefined);
  const [languageOpen, setLanguageOpen] = useState(false);
  const [themeOpen, setThemeOpen] = useState(false);
  const [versionHistoryOpen, setVersionHistoryOpen] = useState(false);
  const [versions, setVersions] = useState<Array<{ version_id: string; created_at: string; description?: string }>>([]);
  const [refineOpen, setRefineOpen] = useState(false);
  const [refineFeedback, setRefineFeedback] = useState('');
  const [refineTargetTypes, setRefineTargetTypes] = useState<Array<'pptx' | 'docx'>>([
    'pptx',
    'docx',
  ]);
  const [refining, setRefining] = useState(false);

  // Model setup state
  const currentModelId = useSettingsStore((s) => s.modelId);
  const needsSetup = !currentModelId;

  // Export
  const { exporting: isExporting, exportPPTX, exportResourcePack } = useExportPPTX();
  const [exportMenuOpen, setExportMenuOpen] = useState(false);
  const exportRef = useRef<HTMLDivElement>(null);
  const stage = useStageStore((s) => s.stage);
  const scenes = useStageStore((s) => s.scenes);
  const generatingOutlines = useStageStore((s) => s.generatingOutlines);
  const failedOutlines = useStageStore((s) => s.failedOutlines);
  const mediaTasks = useMediaGenerationStore((s) => s.tasks);
  const backendSessionId = (stage?.backendSessionId || '').trim();

  const canExport =
    scenes.length > 0 &&
    generatingOutlines.length === 0 &&
    failedOutlines.length === 0 &&
    Object.values(mediaTasks).every((task) => task.status === 'done' || task.status === 'failed');

  const languageRef = useRef<HTMLDivElement>(null);
  const themeRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  const handleClickOutside = useCallback(
    (e: MouseEvent) => {
      if (languageOpen && languageRef.current && !languageRef.current.contains(e.target as Node)) {
        setLanguageOpen(false);
      }
      if (themeOpen && themeRef.current && !themeRef.current.contains(e.target as Node)) {
        setThemeOpen(false);
      }
      if (exportMenuOpen && exportRef.current && !exportRef.current.contains(e.target as Node)) {
        setExportMenuOpen(false);
      }
    },
    [languageOpen, themeOpen, exportMenuOpen],
  );

  useEffect(() => {
    if (languageOpen || themeOpen || exportMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [languageOpen, themeOpen, exportMenuOpen, handleClickOutside]);

  return (
    <>
      <header className="h-20 px-8 flex items-center justify-between z-10 bg-transparent gap-4">
        <div className="flex items-center gap-3 min-w-0 flex-1">
          <button
            onClick={() => router.push('/')}
            className="shrink-0 p-2 rounded-lg text-gray-400 dark:text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
            title={t('generation.backToHome')}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex flex-col min-w-0">
            <span className="text-[10px] uppercase tracking-widest font-bold text-gray-400 dark:text-gray-500 mb-0.5">
              {t('stage.currentScene')}
            </span>
            <h1
              className="text-xl font-bold text-gray-800 dark:text-gray-200 tracking-tight truncate"
              suppressHydrationWarning
            >
              {currentSceneTitle || t('common.loading')}
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-4 bg-white/60 dark:bg-gray-800/60 backdrop-blur-md px-2 py-1.5 rounded-full border border-gray-100/50 dark:border-gray-700/50 shadow-sm shrink-0">
          {/* Language Selector */}
          <div className="relative" ref={languageRef}>
            <button
              onClick={() => {
                setLanguageOpen(!languageOpen);
                setThemeOpen(false);
              }}
              className="flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-bold text-gray-500 dark:text-gray-400 hover:bg-white dark:hover:bg-gray-700 hover:text-gray-800 dark:hover:text-gray-200 hover:shadow-sm transition-all"
            >
              {locale === 'zh-CN' ? 'CN' : 'EN'}
            </button>
            {languageOpen && (
              <div className="absolute top-full mt-2 right-0 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg overflow-hidden z-50 min-w-[120px]">
                <button
                  onClick={() => {
                    setLocale('zh-CN');
                    setLanguageOpen(false);
                  }}
                  className={cn(
                    'w-full px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors',
                    locale === 'zh-CN' &&
                      'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400',
                  )}
                >
                  简体中文
                </button>
                <button
                  onClick={() => {
                    setLocale('en-US');
                    setLanguageOpen(false);
                  }}
                  className={cn(
                    'w-full px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors',
                    locale === 'en-US' &&
                      'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400',
                  )}
                >
                  English
                </button>
              </div>
            )}
          </div>

          <div className="w-[1px] h-4 bg-gray-200 dark:bg-gray-700" />

          {/* Theme Selector */}
          <div className="relative" ref={themeRef}>
            <button
              onClick={() => {
                setThemeOpen(!themeOpen);
                setLanguageOpen(false);
              }}
              className="p-2 rounded-full text-gray-400 dark:text-gray-500 hover:bg-white dark:hover:bg-gray-700 hover:text-gray-800 dark:hover:text-gray-200 hover:shadow-sm transition-all group"
            >
              {theme === 'light' && <Sun className="w-4 h-4" />}
              {theme === 'dark' && <Moon className="w-4 h-4" />}
              {theme === 'system' && <Monitor className="w-4 h-4" />}
            </button>
            {themeOpen && (
              <div className="absolute top-full mt-2 right-0 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg overflow-hidden z-50 min-w-[140px]">
                <button
                  onClick={() => {
                    setTheme('light');
                    setThemeOpen(false);
                  }}
                  className={cn(
                    'w-full px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors flex items-center gap-2',
                    theme === 'light' &&
                      'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400',
                  )}
                >
                  <Sun className="w-4 h-4" />
                  {t('settings.themeOptions.light')}
                </button>
                <button
                  onClick={() => {
                    setTheme('dark');
                    setThemeOpen(false);
                  }}
                  className={cn(
                    'w-full px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors flex items-center gap-2',
                    theme === 'dark' &&
                      'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400',
                  )}
                >
                  <Moon className="w-4 h-4" />
                  {t('settings.themeOptions.dark')}
                </button>
                <button
                  onClick={() => {
                    setTheme('system');
                    setThemeOpen(false);
                  }}
                  className={cn(
                    'w-full px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors flex items-center gap-2',
                    theme === 'system' &&
                      'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400',
                  )}
                >
                  <Monitor className="w-4 h-4" />
                  {t('settings.themeOptions.system')}
                </button>
              </div>
            )}
          </div>

          <div className="w-[1px] h-4 bg-gray-200 dark:bg-gray-700" />

          {/* Settings Button */}
          <div className="relative">
            <button
              onClick={() => setSettingsOpen(true)}
              className={cn(
                'p-2 rounded-full text-gray-400 dark:text-gray-500 hover:bg-white dark:hover:bg-gray-700 hover:text-gray-800 dark:hover:text-gray-200 hover:shadow-sm transition-all group',
                needsSetup && 'animate-setup-glow',
              )}
            >
              <Settings className="w-4 h-4 group-hover:rotate-90 transition-transform duration-500" />
            </button>
            {needsSetup && (
              <>
                <span className="absolute -top-0.5 -right-0.5 flex h-3 w-3">
                  <span className="animate-setup-ping absolute inline-flex h-full w-full rounded-full bg-violet-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-violet-500" />
                </span>
                <span className="animate-setup-float absolute top-full mt-2 right-0 whitespace-nowrap text-[11px] font-medium text-violet-600 dark:text-violet-400 bg-violet-50 dark:bg-violet-950/40 border border-violet-200 dark:border-violet-800/50 px-2 py-0.5 rounded-full shadow-sm pointer-events-none">
                  {t('settings.setupNeeded')}
                </span>
              </>
            )}
          </div>
        </div>

        {/* Quick Refine Button */}
        <button
          onClick={() => {
            if (!backendSessionId) {
              toast.error(t('export.backendSessionMissing'));
              return;
            }
            setRefineOpen(true);
          }}
          disabled={!backendSessionId}
          title={t('export.refineMenuLabel')}
          className={cn(
            'shrink-0 h-9 px-3 rounded-full border text-xs font-medium transition-colors flex items-center gap-1.5',
            backendSessionId
              ? 'border-emerald-200/70 dark:border-emerald-800/50 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-50/70 dark:hover:bg-emerald-900/20'
              : 'border-gray-200 dark:border-gray-700 text-gray-400 dark:text-gray-600 cursor-not-allowed',
          )}
        >
          <MessageSquarePlus className="w-3.5 h-3.5" />
          <span>{t('export.refineMenuLabel')}</span>
        </button>

        {/* Export Dropdown */}
        <div className="relative" ref={exportRef}>
          <button
            onClick={() => {
              if (canExport && !isExporting) setExportMenuOpen(!exportMenuOpen);
            }}
            disabled={!canExport || isExporting}
            title={
              canExport
                ? isExporting
                  ? t('export.exporting')
                  : t('export.pptx')
                : t('share.notReady')
            }
            className={cn(
              'shrink-0 p-2 rounded-full transition-all',
              canExport && !isExporting
                ? 'text-gray-400 dark:text-gray-500 hover:bg-white dark:hover:bg-gray-700 hover:text-gray-800 dark:hover:text-gray-200 hover:shadow-sm'
                : 'text-gray-300 dark:text-gray-600 cursor-not-allowed opacity-50',
            )}
          >
            {isExporting ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Download className="w-4 h-4" />
            )}
          </button>
          {exportMenuOpen && (
            <div className="absolute top-full mt-2 right-0 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg overflow-hidden z-50 min-w-[200px]">
              <button
                onClick={() => {
                  setExportMenuOpen(false);
                  exportPPTX();
                }}
                className="w-full px-4 py-2.5 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors flex items-center gap-2.5"
              >
                <FileDown className="w-4 h-4 text-gray-400 shrink-0" />
                <span>{t('export.pptx')}</span>
              </button>
              {backendSessionId && (
                <button
                  onClick={() => {
                    setExportMenuOpen(false);
                    window.open(
                      `/api/artifacts/download?sessionId=${encodeURIComponent(backendSessionId)}&type=docx`,
                      '_blank',
                    );
                  }}
                  className="w-full px-4 py-2.5 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors flex items-center gap-2.5"
                >
                  <FileDown className="w-4 h-4 text-gray-400 shrink-0" />
                  <span>{t('export.docx')}</span>
                </button>
              )}
              <button
                onClick={() => {
                  setExportMenuOpen(false);
                  exportResourcePack();
                }}
                className="w-full px-4 py-2.5 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors flex items-center gap-2.5"
              >
                <Package className="w-4 h-4 text-gray-400 shrink-0" />
                <div>
                  <div>{t('export.resourcePack')}</div>
                  <div className="text-[11px] text-gray-400 dark:text-gray-500">
                    {t('export.resourcePackDesc')}
                  </div>
                </div>
              </button>
              <div className="border-t border-gray-100 dark:border-gray-700 my-1" />
              <button
                onClick={() => {
                  setExportMenuOpen(false);
                  if (!backendSessionId) {
                    toast.error(t('export.backendSessionMissing'));
                    return;
                  }
                  window.open(
                    `/api/artifacts/export-gif?session_id=${encodeURIComponent(backendSessionId)}`,
                    '_blank',
                  );
                }}
                className="w-full px-4 py-2.5 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors flex items-center gap-2.5"
              >
                <Film className="w-4 h-4 text-gray-400 shrink-0" />
                <div>
                  <div>{t('export.gifAnimation')}</div>
                  <div className="text-[11px] text-gray-400 dark:text-gray-500">{t('export.gifAnimationDesc')}</div>
                </div>
              </button>
              <button
                onClick={() => {
                  setExportMenuOpen(false);
                  if (!backendSessionId) {
                    toast.error(t('export.backendSessionMissing'));
                    return;
                  }
                  window.open(
                    `/api/artifacts/bundle?session_id=${encodeURIComponent(backendSessionId)}`,
                    '_blank',
                  );
                }}
                className="w-full px-4 py-2.5 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors flex items-center gap-2.5"
              >
                <Archive className="w-4 h-4 text-gray-400 shrink-0" />
                <div>
                  <div>{t('export.fullBundle')}</div>
                  <div className="text-[11px] text-gray-400 dark:text-gray-500">{t('export.fullBundleDesc')}</div>
                </div>
              </button>
              <div className="border-t border-gray-100 dark:border-gray-700 my-1" />
              <button
                onClick={async () => {
                  setExportMenuOpen(false);
                  setVersionHistoryOpen(true);
                  if (!backendSessionId) {
                    setVersions([]);
                    toast.error(t('export.backendSessionMissing'));
                    return;
                  }
                  try {
                    const resp = await fetch(`/api/versions?sessionId=${encodeURIComponent(backendSessionId)}`);
                    if (resp.ok) {
                      const data = await resp.json();
                      setVersions(data.versions || []);
                    }
                  } catch { /* ignore */ }
                }}
                className="w-full px-4 py-2.5 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors flex items-center gap-2.5"
              >
                <History className="w-4 h-4 text-gray-400 shrink-0" />
                <span>{t('export.versionHistory')}</span>
              </button>
              <button
                onClick={() => {
                  setExportMenuOpen(false);
                  setRefineOpen(true);
                }}
                className="w-full px-4 py-2.5 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors flex items-center gap-2.5"
              >
                <MessageSquarePlus className="w-4 h-4 text-gray-400 shrink-0" />
                <div>
                  <div>{t('export.refineMenuLabel')}</div>
                  <div className="text-[11px] text-gray-400 dark:text-gray-500">{t('export.refineMenuDesc')}</div>
                </div>
              </button>
            </div>
          )}
        </div>
      </header>
      <SettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} initialSection={settingsSection} />

      {/* Version History Dialog */}
      {versionHistoryOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm" onClick={() => setVersionHistoryOpen(false)}>
          <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl w-[480px] max-h-[70vh] overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="px-5 py-4 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-emerald-500" />
                <h2 className="font-semibold">{t('export.versionHistoryTitle')}</h2>
              </div>
              <button onClick={() => setVersionHistoryOpen(false)} className="p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400">
                <Settings className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 overflow-y-auto max-h-[50vh]">
              {versions.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">{t('export.noVersions')}</p>
              ) : (
                <div className="space-y-3">
                  {versions.map((v, i) => (
                    <div key={v.version_id} className="flex items-center justify-between p-3 rounded-lg border border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800/50">
                      <div>
                        <div className="text-sm font-medium">{t('export.versionLabel')} {versions.length - i}</div>
                        <div className="text-xs text-muted-foreground">{v.created_at}</div>
                        {v.description && <div className="text-xs text-muted-foreground mt-0.5">{v.description}</div>}
                      </div>
                      {i > 0 && (
                        <button
                          onClick={async () => {
                            if (!backendSessionId) {
                              toast.error(t('export.backendSessionMissing'));
                              return;
                            }
                            try {
                              const resp = await fetch('/api/versions', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({
                                  session_id: backendSessionId,
                                  version_id: v.version_id,
                                }),
                              });
                              if (resp.ok) {
                                toast.success(t('export.rollbackSuccess'));
                                setVersionHistoryOpen(false);
                              } else {
                                toast.error(t('export.rollbackFailed'));
                              }
                            } catch {
                              toast.error('回滚失败');
                            }
                          }}
                          className="px-3 py-1 text-xs font-medium text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-lg transition-colors"
                        >
                          {t('export.rollback')}
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Refine Dialog */}
      {refineOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm" onClick={() => setRefineOpen(false)}>
          <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl w-[520px] overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="px-5 py-4 border-b border-gray-100 dark:border-gray-800 flex items-center gap-2">
              <MessageSquarePlus className="w-5 h-5 text-emerald-500" />
              <h2 className="font-semibold">{t('export.refineTitle')}</h2>
            </div>
            <div className="p-5 space-y-4">
              <p className="text-sm text-muted-foreground">
                {t('export.refineDesc')}
              </p>
              <div className="space-y-2">
                <div className="text-xs text-muted-foreground">{t('export.refineHint')}</div>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    '减数分裂那页增加动画演示各个阶段',
                    '在中心法则后面加一个互动测验',
                    '细胞结构图增加线粒体的详细标注',
                    '把DNA复制的讲解拆成两页更清晰',
                  ].map((ex) => (
                    <button
                      key={ex}
                      onClick={() => setRefineFeedback(ex)}
                      className="px-2.5 py-1 text-xs bg-gray-100 dark:bg-gray-800 rounded-full hover:bg-emerald-50 dark:hover:bg-emerald-900/20 hover:text-emerald-600 transition-colors"
                    >
                      {ex}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <div className="text-xs text-muted-foreground">优化目标</div>
                <div className="flex gap-2">
                  {[
                    { type: 'pptx' as const, label: 'PPT' },
                    { type: 'docx' as const, label: 'Word' },
                  ].map((item) => {
                    const active = refineTargetTypes.includes(item.type);
                    return (
                      <button
                        key={item.type}
                        type="button"
                        onClick={() => {
                          setRefineTargetTypes((prev) => {
                            if (prev.includes(item.type)) {
                              return prev.length > 1 ? prev.filter((t) => t !== item.type) : prev;
                            }
                            return [...prev, item.type];
                          });
                        }}
                        className={cn(
                          'px-2.5 py-1 text-xs rounded-full border transition-colors',
                          active
                            ? 'border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300'
                            : 'border-gray-200 text-muted-foreground hover:bg-gray-100 dark:border-gray-700 dark:hover:bg-gray-800',
                        )}
                      >
                        {item.label}
                      </button>
                    );
                  })}
                </div>
              </div>
              <textarea
                value={refineFeedback}
                onChange={(e) => setRefineFeedback(e.target.value)}
                placeholder={t('export.refinePlaceholder')}
                className="w-full h-28 px-3 py-2 text-sm border rounded-lg bg-background resize-none focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              />
              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setRefineOpen(false)}
                  className="px-4 py-2 text-sm rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                >
                  {t('common.cancel')}
                </button>
                <button
                  disabled={refining || !refineFeedback.trim() || refineTargetTypes.length === 0}
                  onClick={async () => {
                    setRefining(true);
                    if (!backendSessionId) {
                      toast.error(t('export.backendSessionMissing'));
                      setRefining(false);
                      return;
                    }
                    try {
                      const resp = await fetch('/api/courseware/refine', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                          session_id: backendSessionId,
                          feedback: refineFeedback,
                          target_types: refineTargetTypes,
                        }),
                      });
                      if (resp.ok) {
                        toast.success(t('export.refineSuccess'));
                        setRefineOpen(false);
                        setRefineFeedback('');
                      } else {
                        toast.error(t('export.refineFailed'));
                      }
                    } catch {
                      toast.error(t('export.refineFailed'));
                    } finally {
                      setRefining(false);
                    }
                  }}
                    className={cn(
                      'px-4 py-2 text-sm font-medium rounded-lg transition-all',
                      refining || !refineFeedback.trim() || refineTargetTypes.length === 0
                        ? 'bg-gray-200 dark:bg-gray-700 text-gray-400 cursor-not-allowed'
                        : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-sm',
                    )}
                  >
                  {refining ? t('export.refining') : t('export.refineSubmit')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
